<?php

include 'config/database.php';
// //ranking 
$query = "SELECT id, title, productname, value FROM wasabi ORDER BY value DESC";

$stmt = $con->prepare($query);

$stmt->execute();



$count=0;

while( $ro = $stmt->fetch(PDO::FETCH_ASSOC)){
  $count++;
  if($count>3){
    break;
  }

  echo "rank ".$count." is ".$ro['title']." with point ".$ro['value'] . "<br />";
}


?>
